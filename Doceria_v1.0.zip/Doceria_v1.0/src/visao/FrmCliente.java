package visao;
import java.awt.EventQueue;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.JRadioButton;
import javax.swing.JPanel;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.awt.event.ActionEvent;
import javax.swing.border.TitledBorder;

import controle.CtrlCliente;
import utilitarios.Endereco;

import java.awt.Font;
import javax.swing.border.EtchedBorder;
import java.awt.Color;
import javax.swing.JCheckBox;
import javax.swing.SwingConstants;
import javax.swing.border.BevelBorder;

public class FrmCliente {
	private JFrame frame;
	private JTextField textField;
	private final ButtonGroup buttonGroup = new ButtonGroup();
	private JTextField textField_1;
	private JTextField textField_2;
	private JTextField txtLogradouro;
	private JTextField txtCEP;
	private JTextField txtBairro;
	private JTextField txtCidade;
	private JTextField txtUF;
	private JTextField txtNumero;
	private JTextField textField_4;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FrmCliente window = new FrmCliente();
					window.frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public FrmCliente() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frame = new JFrame();
		frame.setBounds(100, 100, 534, 487);
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		frame.getContentPane().setLayout(null);
		
		JLabel lblNome = new JLabel("Nome");
		lblNome.setFont(new Font("Lucida Grande", Font.PLAIN, 14));
		lblNome.setBounds(17, 31, 61, 16);
		frame.getContentPane().add(lblNome);
		
		textField = new JTextField();
		textField.setBounds(90, 26, 207, 26);
		frame.getContentPane().add(textField);
		textField.setColumns(10);
		
		JPanel pnSexo = new JPanel();
		pnSexo.setBorder(new TitledBorder(null, "Sexo", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		pnSexo.setBounds(17, 60, 134, 78);
		frame.getContentPane().add(pnSexo);
		pnSexo.setLayout(null);
		
		JRadioButton rdbtnNewRadioButton = new JRadioButton("");
		rdbtnNewRadioButton.setBounds(24, 20, 51, 23);
		buttonGroup.add(rdbtnNewRadioButton);
		pnSexo.add(rdbtnNewRadioButton);
		
		JRadioButton rdbtnNewRadioButton_1 = new JRadioButton("");
		rdbtnNewRadioButton_1.setBounds(25, 44, 50, 23);
		buttonGroup.add(rdbtnNewRadioButton_1);
		pnSexo.add(rdbtnNewRadioButton_1);
		
		JLabel lblNewLabel = new JLabel("");
		lblNewLabel.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel.setIcon(new ImageIcon(FrmCliente.class.getResource("/img/user_rosa.png")));
		lblNewLabel.setBounds(24, 20, 51, 23);
		pnSexo.add(lblNewLabel);
		
		JLabel lblNewLabel_1 = new JLabel("");
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.RIGHT);
		lblNewLabel_1.setIcon(new ImageIcon(FrmCliente.class.getResource("/img/user_azul.png")));
		lblNewLabel_1.setBounds(25, 50, 50, 16);
		pnSexo.add(lblNewLabel_1);
		
		JPanel panel_1 = new JPanel();
		panel_1.setBorder(new TitledBorder(new EtchedBorder(EtchedBorder.LOWERED, null, null), "Fones", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel_1.setBounds(189, 72, 220, 109);
		frame.getContentPane().add(panel_1);
		panel_1.setLayout(null);
		
		textField_1 = new JTextField();
		textField_1.setBounds(16, 29, 130, 26);
		panel_1.add(textField_1);
		textField_1.setColumns(10);
		
		textField_2 = new JTextField();
		textField_2.setBounds(16, 68, 130, 26);
		panel_1.add(textField_2);
		textField_2.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("");
		lblNewLabel_2.setBounds(158, 29, 16, 26);
		panel_1.add(lblNewLabel_2);
		lblNewLabel_2.setIcon(new ImageIcon(FrmCliente.class.getResource("/img/whatsapp.png")));
		
		JLabel lblNewLabel_3 = new JLabel("");
		lblNewLabel_3.setIcon(new ImageIcon(FrmCliente.class.getResource("/img/casa-de-boneca.png")));
		lblNewLabel_3.setBounds(153, 73, 24, 16);
		panel_1.add(lblNewLabel_3);
		
		JPanel pnEndereco = new JPanel();
		pnEndereco.setBorder(new TitledBorder(null, "Endere\u00E7o", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		pnEndereco.setBounds(17, 198, 476, 195);
		frame.getContentPane().add(pnEndereco);
		pnEndereco.setLayout(null);
		
		JLabel lnLogradouro = new JLabel("Rua");
		lnLogradouro.setBounds(19, 56, 36, 21);
		pnEndereco.add(lnLogradouro);
		
		txtLogradouro = new JTextField();
		txtLogradouro.setBounds(67, 53, 207, 26);
		pnEndereco.add(txtLogradouro);
		txtLogradouro.setColumns(10);
		
		JLabel lblCep = new JLabel("CEP");
		lblCep.setBounds(19, 23, 36, 21);
		pnEndereco.add(lblCep);
		
		txtCEP = new JTextField();
		txtCEP.setBounds(57, 17, 130, 26);
		pnEndereco.add(txtCEP);
		txtCEP.setColumns(10);
		
		JButton btnPesquisaCEP = new JButton("Procurar CEP");
		btnPesquisaCEP.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				// exemplo composição
				CtrlCliente control = new CtrlCliente();
				txtLogradouro.setText("");
				//colocar método que limpa as caixas de texto do endereço
				Endereco end;
				try {
					end = control.buscarCep(txtCEP.getText());
					txtLogradouro.setText(end.getLogradouro());
			        txtBairro.setText(end.getBairro());
			        txtCidade.setText(end.getLocalidade());
			        txtUF.setText(end.getUf());
				} catch (IllegalArgumentException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
					
				} catch (IllegalAccessException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
		        
		        
			}
		});
		btnPesquisaCEP.setIcon(new ImageIcon(FrmCliente.class.getResource("/img/pesquisa-de-lupa.png")));
		btnPesquisaCEP.setBounds(192, 17, 117, 29);
		pnEndereco.add(btnPesquisaCEP);
		
		JLabel lbBairro = new JLabel("Bairro");
		lbBairro.setBounds(19, 119, 36, 21);
		pnEndereco.add(lbBairro);
		
		txtBairro = new JTextField();
		txtBairro.setColumns(10);
		txtBairro.setBounds(67, 120, 199, 26);
		pnEndereco.add(txtBairro);
		
		JLabel lblCidade = new JLabel("Cidade");
		lblCidade.setBounds(19, 147, 48, 21);
		pnEndereco.add(lblCidade);
		
		txtCidade = new JTextField();
		txtCidade.setColumns(10);
		txtCidade.setBounds(67, 148, 199, 26);
		pnEndereco.add(txtCidade);
		
		JLabel lblUF = new JLabel("UF");
		lblUF.setBounds(314, 145, 28, 21);
		pnEndereco.add(lblUF);
		
		txtUF = new JTextField();
		txtUF.setColumns(10);
		txtUF.setBounds(340, 142, 76, 26);
		pnEndereco.add(txtUF);
		
		JLabel lblNumero = new JLabel("Número");
		lblNumero.setBounds(286, 59, 54, 21);
		pnEndereco.add(lblNumero);
		
		txtNumero = new JTextField();
		txtNumero.setColumns(10);
		txtNumero.setBounds(340, 53, 76, 26);
		pnEndereco.add(txtNumero);
		
		JLabel lblComplemento = new JLabel("Complemento");
		lblComplemento.setBounds(19, 95, 107, 21);
		pnEndereco.add(lblComplemento);
		
		textField_4 = new JTextField();
		textField_4.setBounds(121, 91, 76, 26);
		pnEndereco.add(textField_4);
		textField_4.setColumns(10);
		
		JButton btnSalvar = new JButton("Salvar");
		btnSalvar.setIcon(null);
		btnSalvar.setBounds(17, 418, 117, 29);
		frame.getContentPane().add(btnSalvar);
		
		JButton btnProcCliente = new JButton("");
		btnProcCliente.setIcon(new ImageIcon(FrmCliente.class.getResource("/img/pesquisa-de-lupa.png")));
		btnProcCliente.setBounds(309, 27, 53, 29);
		frame.getContentPane().add(btnProcCliente);
		
		JButton btnExcluir = new JButton("");
		btnExcluir.setIcon(new ImageIcon(FrmCliente.class.getResource("/img/6239_32x32.png")));
		btnExcluir.setBounds(370, 31, 61, 29);
		frame.getContentPane().add(btnExcluir);
	}
}
