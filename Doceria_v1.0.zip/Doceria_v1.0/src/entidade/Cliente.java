package entidade;

public class Cliente {
	String nome;
	String sexo;
	String fone;
	String celular1;
	String celular2;
	String celular3;
	String endereco;
	String cep;
	String numero;
	String complemento;
	String cidade;
	String UF;
	
	public Cliente(String nome, String sexo, String fone, String celular1, String celular2, String celular3,
			String endereco, String cep, String numero, String complemento, String cidade, String uF) {
		super();
		this.nome = nome;
		this.sexo = sexo;
		this.fone = fone;
		this.celular1 = celular1;
		this.celular2 = celular2;
		this.celular3 = celular3;
		this.endereco = endereco;
		this.cep = cep;
		this.numero = numero;
		this.complemento = complemento;
		this.cidade = cidade;
		UF = uF;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getSexo() {
		return sexo;
	}
	public void setSexo(String sexo) {
		this.sexo = sexo;
	}
	public String getFone() {
		return fone;
	}
	public void setFone(String fone) {
		this.fone = fone;
	}
	public String getCelular1() {
		return celular1;
	}
	public void setCelular1(String celular1) {
		this.celular1 = celular1;
	}
	public String getCelular2() {
		return celular2;
	}
	public void setCelular2(String celular2) {
		this.celular2 = celular2;
	}
	public String getCelular3() {
		return celular3;
	}
	public void setCelular3(String celular3) {
		this.celular3 = celular3;
	}
	public String getEndereco() {
		return endereco;
	}
	public void setEndereco(String endereco) {
		this.endereco = endereco;
	}
	public String getCep() {
		return cep;
	}
	public void setCep(String cep) {
		this.cep = cep;
	}
	public String getNumero() {
		return numero;
	}
	public void setNumero(String numero) {
		this.numero = numero;
	}
	public String getComplemento() {
		return complemento;
	}
	public void setComplemento(String complemento) {
		this.complemento = complemento;
	}
	public String getCidade() {
		return cidade;
	}
	public void setCidade(String cidade) {
		this.cidade = cidade;
	}
	public String getUF() {
		return UF;
	}
	public void setUF(String uF) {
		UF = uF;
	}
	
	
	
}
