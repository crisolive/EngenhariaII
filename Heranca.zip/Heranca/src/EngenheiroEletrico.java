
public class EngenheiroEletrico extends Engenheiro {

	@Override 
	public double bonus() {
		
		return (super.getSalario()*33) ;
	}
}
