
public class Gerente extends Funcionario  {
	int adicional;
	
	public int getAdicional() {
		return adicional;
	}

	public void setAdicional(int adicional) {
		this.adicional = adicional;
	}
	
	public double bonus() {
		return  (super.getSalario()*1.8 + 777);
	}
}
