
public class Main {

	public static void main(String[] args) {
//classe abstrata, não pode ser instanciada
//		Funcionario f1 = new Funcionario();
//		f1.setNome("Ze");
//		f1.setSalario(-8888);
//		//f1.salario = -555;
//		//imprimirFuncionario(f1);
//		System.out.println("Funcionario " + f1.getNome() +
//				" Salario= " + f1.getSalario());
		
		
		Engenheiro e1 = new Engenheiro ();
		e1.setNome( "Ian");
		//e1.nome = "Iann";
		e1.setCpf(123);
//a atribuicao abaixo era apresentar o problema do encapsulamento
//		e1.setSalario(-9999);
		e1.setSalario(1000);
		e1.setCrea ( 1234565);
		//imprimirEngenheiro(e1);
		imprimirFuncionario(e1);
		
		
//chamado do método privado 
		//e1.chamandoPrivate();
		//imprimirFuncionario(e1);
		
		
		Motorista m1 = new Motorista ("123", "Karl", 1000);
		m1.setNome ("Karl Von Dix");
//demonstracao do uso do construtor iniciando os atributos
//		m1.setNome( "Karl");
//		m1.setSalario (1000);
		
		imprimirFuncionario(m1);
		
		//imprimirMotorista(m1);
		
		
		//imprimirFuncionario(m1);
		Gerente g1 = new Gerente();
		g1.setNome ( "Isa");
		g1.setSalario (1000);
		imprimirFuncionario(g1);
		
		//imprimirGerente(g1);
		
		
		Presidente p1 = new Presidente ();
		p1.setNome("Ze das couves");
		p1.setSalario(1000);
		//imprimirPresidente(p1);
		
		imprimirFuncionario(p1);
		
	}


//	//impressao de cada filha
//	private static void imprimirPresidente(Presidente p1) {
//		System.out.println("Funcionario " + p1.getNome() +
//				" Salario= " + p1.getSalario() +
//				" Bonus = " + p1.bonus());		
//	}
//
//	private static void imprimirGerente(Gerente g1) {
//		System.out.println("Funcionario " + g1.getNome() +
//		" Salario= " + g1.getSalario() +
//		" Bonus = " + g1.bonus());
//		
//	}
//	private static void imprimirMotorista(Motorista m1) {
//		System.out.println("Funcionario " + m1.getNome() +
//				" Salario= " + m1.getSalario() +
//				" Bonus = " + m1.bonus());		
//	}
//	private static void imprimirEngenheiro(Engenheiro e1) {
//		System.out.println("Funcionario " + e1.getNome() +
//				" Salario= " + e1.getSalario() +
//				" Bonus = " + e1.bonus());		
//	}
//
//
	private static void imprimirFuncionario(Funcionario xxx) {
		//preste atencao que a impressão sempre é de Funcionario
		//caso queira imprimir o tipo de objeto, deve-se utilizar 
		//f1.getClass().getName() que retorna o nome da classe 
		//o codigo está comentado no sysout abaixo
		System.out.println("Funcionario " + xxx.getNome() +
				" Salario= " + xxx.getSalario() +
				" Bonus= " + xxx.bonus());
		
//		System.out.println( f1.getNome() + " é "+ f1.getClass().getName() +
//				" e seu salario é " 
//				+ f1.getSalario() +
//				", sua bonificacao é " + f1.bonus());
//		
//		System.out.println("Nome "+ xxx.getNome() + " Salario= "+ xxx.getSalario());
		
	}
}
