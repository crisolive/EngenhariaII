
public class Presidente extends Funcionario  {

	int premiacao;

	public int getPremiacao() {
		return premiacao;
	}

	public void setPremiacao(int premiacao) {
		this.premiacao = premiacao;
	}


	@Override
	public double bonus() {
		return super.getSalario()* 798;
	}
}
