
public class Engenheiro extends Funcionario{
	 int diasFerias;
	 String localFerias;
	 int crea;
	
	@Override 
	public double bonus() {
		this.diasFerias = 60;
		this.localFerias = "Caribe";
		return (super.getSalario()*2) ;
	}

	
	public int getDiasFerias() {
		return diasFerias;
	}
	public void setDiasFerias(int diasFerias) {
		this.diasFerias = diasFerias;
	}
	public String getLocalFerias() {
		return localFerias;
	}
	public void setLocalFerias(String localFerias) {
		this.localFerias = localFerias;
	}
	public int getCrea() {
		return crea;
	}
	public void setCrea(int crea) {
		this.crea = crea;
	}

}
