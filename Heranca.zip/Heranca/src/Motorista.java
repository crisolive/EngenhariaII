
public class Motorista extends Funcionario{
	
	private String cnh;
	
	public Motorista(String cnh, String nome, double salario) {
		super(nome,salario);
		this.cnh = cnh;
	}

	public String getCnh() {
		return cnh;
	}

	public void setCnh(String cnh) {
		this.cnh = cnh;
	}
	public double bonus() {
		return super.getSalario()*1.3;
	}

}
