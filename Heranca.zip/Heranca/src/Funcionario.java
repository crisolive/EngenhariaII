
public abstract class Funcionario{
	
	  String nome;
	  double salario;
	  int cpf;
	  int ww;
	
	public Funcionario(String nome, double salario) {
		this.nome = nome;
		this.salario = salario;
	}
	
	
	public Funcionario() {
		super();
	}


	public abstract  double bonus(); 
//	
//	public abstract  double xx(); 
	
	public String zz() {
		return "corpo vazio";
	}
//	{
//		return this.salario *1.2;
//	}

	public String getNome() {
		return nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public double getSalario() {
		return salario;
	}

	public void setSalario(double salario) {
		this.salario = salario;
	}

	public int getCpf() {
		return cpf;
	}

	public void setCpf(int cpf) {
		this.cpf = cpf;
	}
	 
	 

//	private void qqcoisa () {
//		System.out.println("passando private");
//	}
//		
//	public void chamandoPrivate () {
//	this.qqcoisa();
//}
	
//	public void setSalario(double salario) {
//		if (salario > 0)
//			this.salario = salario;
//		else 
//			this.salario = 0;
//	}
}
