package fontes;


import entidades.*;

public class Main {

	public static void main(String[] args) {
		
//		Funcionario f1 = new Funcionario();
//		f1.nome = "Paola";
//		f1.setSalario(-3000);
//		System.out.println("Funcionario: " + f1.nome + " Bonus: " + f1.bonus() + "Salario " + f1.getSalario());
//		
//		Cliente c1 = new Cliente ();
//		c1.setNome("Cliente Mane");
//		c1.setLogin("456");
//		c1.setSenha("456");
//		SysPed.validarPedido(c1);
		
		Presidente p1 = new Presidente();
		p1.setNome("Presidente Ian");
		p1.setSalario(1000);
		p1.setFerias("Osasco");
		p1.setLogin("123");
		p1.setSenha("123");
		//imprimirFuncionario(p1);
		//SysPed.validarPedido(p1);
		
		Gerente g1 = new Gerente ();
		g1.setNome("Gerente Karl");
		g1.setSalario(1000);
		g1.setFerias("Santos");
		//imprimirFuncionario(g1);
		//SysPed.validarPedido(g1);
		//não usar o método abaixo
		//pois o acoplamento é alto
		//SysCon.validarPedido(g1, p1);
		SysPed.validarPedido(g1);
		
		Terceiros tc = new Terceiros();
		tc.setNome("Tecnico Gandhi");
		SysPed.validarPedido(tc);
		
		Fornecedor for1  =new  Fornecedor();
		for1.setNome("Fornecedor Poligono");
		SysPed.validarPedido(for1);
	}
	//aqui está a substituição de Liskov, passando a classe mãe
	//e não a filha.
	private static void imprimirFuncionario(Funcionario f1) {
		System.out.println("Nome "+ f1.getNome());
		
	}

//	private static void imprimirGerente(Gerente g1) {
//		System.out.println("Nome "+ g1.getNome());
//		
//	}
	
	
}