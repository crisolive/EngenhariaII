package fontes;

import interfaces.Iacesso;

public class SysPed {
	
// os métodos abaixo foram definidos como static para 
// não instanciar um objeto	
	
//	public static void validarPedido (Gerente g, Presidente p){
//		System.out.println("Validando Pedido Nome " + p.getNome() );
//	} alto acoplamento
	
//	public static void validarPedido (Acesso a1){
//		System.out.println("Validando Pedido Nome " + a1.getNome() );
//	}// diminuindo acoplamento
	
	public static void validarPedido (Iacesso i1){
		System.out.println("Validando Pedido Nome " + i1.getNome() );
	}// menor acoplamento --> abstracao

}
