package classeInterface;

import interfaces.I2;
import interfaces.I3;

public class classe3  implements I2, I3 {

//	@Override
//	public void op1() {
//		// TODO Auto-generated method stub
//		
//	}
	@Override
	public void op2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void op31() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void op32() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public int op33(int x, int y) {
		// TODO Auto-generated method stub
		return 0;
	}

	@Override
	public String op34(String nome) {
		// TODO Auto-generated method stub
		return null;
	}

	

	
}
