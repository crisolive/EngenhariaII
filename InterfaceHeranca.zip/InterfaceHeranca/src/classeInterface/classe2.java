package classeInterface;

import interfaces.I1;
import interfaces.I2;
import interfaces.Iacesso;

public class classe2 implements I1, I2, Iacesso{

	//a classe assina a Interface 2, que herda da Interface 1
	//esta classe tem que implementar os dois médotos da I2
		
	@Override
	public void op1() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void op2() {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void login(String login, String senha) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return null;
	}
	

}
