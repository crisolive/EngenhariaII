package classeInterface;

import interfaces.I1;

public class classe1 implements I1 {

	

//	assina os serviços da Interface 1
	@Override
	public void op1() {
		// TODO Auto-generated method stub
		
	}

}
