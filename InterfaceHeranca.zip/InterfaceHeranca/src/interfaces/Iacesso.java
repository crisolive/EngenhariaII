package interfaces;

public interface Iacesso {
	
	public void login(String login, String senha);
	public String getNome();

}
