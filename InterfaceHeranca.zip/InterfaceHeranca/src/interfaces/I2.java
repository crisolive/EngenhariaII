package interfaces;

public interface I2 {
	public void op2();
}
