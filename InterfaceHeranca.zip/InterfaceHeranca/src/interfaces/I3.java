package interfaces;

public interface I3 {
	public void op31();
	public void op32();
	public int op33(int x, int y);
	public String op34(String nome);
	
}
