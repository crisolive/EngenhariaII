package interfaces;

public interface I1 {
	public void op1();

}
