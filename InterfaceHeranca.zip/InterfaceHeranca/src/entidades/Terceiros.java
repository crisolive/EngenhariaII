package entidades;

import interfaces.Iacesso;

public class Terceiros implements Iacesso { 

	private String nome;
	String login;


	
	@Override
	public void login(String login, String senha) {
		System.out.println("Terceiros");
		
	}

	

	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return this.nome;
	}



	public void setNome(String nome) {
		this.nome = nome;
	}

	
	

}
