package entidades;

import interfaces.Iacesso;

public class Cliente implements  Iacesso{
	private String nome;
	private String login;
	private String senha;
	int cpf;

	@Override
	public String getNome() {
		return this.nome;
	}

	@Override
	public void login(String login, String senha) {
		System.out.println("Ta logando sistema");	
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

	public String getLogin() {
		return login;
	}

	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}
}
