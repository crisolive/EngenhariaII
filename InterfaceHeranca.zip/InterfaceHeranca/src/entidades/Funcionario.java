package entidades;

public class Funcionario {
	String nome;
	private int salario;
	String ferias;
	int inss;
	
	//public abstract double bonus ();
	
//	public String getNome(){
//		return this.nome;
//	}
	public void setFerias(String local){
		this.ferias = local;
	}
	public String getFerias(){
		return this.ferias;
	}
	public void setSalario ( int salario){
		if (salario > 0) 
			this.salario = salario;
	}
	public int getSalario(){
		return this.salario;
	}
	
//	public void op1(){
//		
//	}
	
	public void setNome(String nome) {
		this.nome = nome;
	}
	//////////////////////////
	public String getNome() {
		return nome;
	}
}
