package entidades;

public class Engenheiro extends Funcionario {
	int crea;

//	@Override
//	public double bonus() {
//		return super.getSalario()*3;
//	}
//
//
//	@Override
//	public void login(String login, String senha) {
//		// TODO Auto-generated method stub
//		
//	}

//	@Override
//	public void mostrarAlgo() {
//		// TODO Auto-generated method stub
//		
//	}

	
	
	
	
	
	
	
	
	
	
	
//	public double bonus() {
//		System.out.println("Passando Eng.Bonus");
//		return super.getSalario() * 1.8;
//	}

}
