package entidades;

import interfaces.Iacesso;

public class Tecnico implements Iacesso{

	@Override
	public void login(String login, String senha) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return null;
	}
}
