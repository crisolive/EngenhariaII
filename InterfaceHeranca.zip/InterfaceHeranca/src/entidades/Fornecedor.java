package entidades;

import interfaces.Iacesso;

public class Fornecedor implements Iacesso{
	
	private String nome;
	String login;

	@Override
	public void login(String login, String senha) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String getNome() {
		// TODO Auto-generated method stub
		return this.nome;
	}

	public void setNome(String nome) {
		this.nome = nome;
	}

}
