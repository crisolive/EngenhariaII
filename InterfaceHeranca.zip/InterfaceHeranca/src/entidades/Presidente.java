package entidades;

public class Presidente extends Acesso  {
	int proLabore=500;
	private String login;
	String senha;

	public double bonus() {
		//System.out.println("Passando Presidente .Bonus");
		return super.getSalario()*3 + this.proLabore;
	}

	public int getProLabore() {
		return proLabore;
	}

	public void setProLabore(int proLabore) {
		this.proLabore = proLabore;
	}

//	public String getLogin() {
//		return login;
//	}
//
	public void setLogin(String login) {
		this.login = login;
	}

	public String getSenha() {
		return senha;
	}

	public void setSenha(String senha) {
		this.senha = senha;
	}

	@Override
	public void login(String login, String senha) {
		// TODO Auto-generated method stub
		
	}

	

	
}
