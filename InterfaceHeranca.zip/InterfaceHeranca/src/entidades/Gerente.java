package entidades;

public class Gerente extends Acesso  {
	public double bonus() {
		return super.getSalario() * 2;
	}

	@Override
	public void login(String login, String senha) {
		// TODO Auto-generated method stub	
	}
}
