package entidades;

import interfaces.Iacesso;

public abstract class Acesso extends Funcionario implements Iacesso {
	String usuario;
	String senha;
//	@Override
//	public void login(String login, String senha) {
//		System.out.println("Passando Gerente");
//		
//	}
//	@Override
//	public String getNome() {
//		return super.nome;
//	}
}
